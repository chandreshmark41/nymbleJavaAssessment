package ChandreshCodeBuffer.nymbleAssessment.controller;

public interface ThrottleController {

    Integer calculateThrottle(Integer currentSpeed);

    void setCruiseSpeed(Integer cruiseSpeed);

    Integer getCruiseSpeed();

}
