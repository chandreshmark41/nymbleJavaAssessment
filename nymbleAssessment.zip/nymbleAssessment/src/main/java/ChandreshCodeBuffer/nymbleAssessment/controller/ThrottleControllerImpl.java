package ChandreshCodeBuffer.nymbleAssessment.controller;

import ChandreshCodeBuffer.nymbleAssessment.service.Quantizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ThrottleControllerImpl implements  ThrottleController{


    @Autowired
    Quantizer<Integer> quantizer;

    private Integer cruiseSpeed;

    /***
     * getCruiseSpeed take no param.
     * @return cruiseSpeed
     */
    public Integer getCruiseSpeed() {
        return cruiseSpeed;
    }

    /***
     *
     * @param cruiseSpeed
     * and set value of cruiseSpeed.
     */
    @Override
    public void setCruiseSpeed(Integer cruiseSpeed) {
        this.cruiseSpeed = cruiseSpeed;
    }

    /***
     * @param  currentSpeed
     * @return throttleValue
     */
    @Override
    public Integer calculateThrottle(Integer currentSpeed) {
        return quantizer.quantize(currentSpeed);
    }

    public static void setThrottleValue(Integer throttleControlValue)  {

    }











//    ThrottleController throttleController = new ThrottleControllerImpl();
//    throttleController.setCruiseSpeed();
//    final Integer throttleControlValue = throttleController.calculateThrottle(getCurrentSpeed);
//    setThrottleValue(throttleControlValue);
}
