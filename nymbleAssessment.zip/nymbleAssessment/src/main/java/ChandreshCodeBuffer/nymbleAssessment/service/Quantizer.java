package ChandreshCodeBuffer.nymbleAssessment.service;


public interface Quantizer<T> {

    public T quantize(T speed);
}
