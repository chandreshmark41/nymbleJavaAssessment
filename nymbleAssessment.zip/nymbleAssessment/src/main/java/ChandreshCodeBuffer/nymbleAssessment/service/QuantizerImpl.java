package ChandreshCodeBuffer.nymbleAssessment.service;


import org.springframework.stereotype.Component;

@Component
public class QuantizerImpl implements Quantizer<Integer> {

    public static int upper = 0;
    public  static  int lower = 0;
    public static int throttle = 0;
    public static int range = 2;

    /***
     *
     * @param speed
     * @return
     */
    @Override
    public Integer quantize(Integer speed) {

        if (speed > 70) {
            throttle = 7;
            System.out.println("Speed = "+speed+" And Gear = "+throttle);
            return throttle;
        }

        else if (speed < 0) {
            throttle = 0;
            System.out.println("Speed = "+speed+" And Gear = "+throttle);
            return  throttle;
        }

        else {


            if (speed > upper) {
                throttle++;
                upper = throttle * 10 + range;
                lower = Math.max((throttle - 1) * 10 - range, 0);
            } else if (speed < lower) {
                throttle--;
                upper = throttle * 10 + range;
                lower = Math.max((throttle - 1) * 10 - range, 0);
            }
            System.out.println("Speed = " + speed + " And Gear = " + throttle);
            return throttle;
        }
    }
}
