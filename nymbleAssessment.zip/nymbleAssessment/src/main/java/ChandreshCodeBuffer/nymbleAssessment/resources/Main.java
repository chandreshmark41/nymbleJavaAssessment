package ChandreshCodeBuffer.nymbleAssessment.resources;

import ChandreshCodeBuffer.nymbleAssessment.controller.ThrottleController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Main {

    @Autowired
    ThrottleController throttleController;

    /**
     * throttleMethod() is called on api end point /callApi.
     */
    @GetMapping("/callApi")
    public void throttleMethod() {
        System.out.println("Nymble Assessment is runnig");
        int[] arr = {1,6,11,16,17,18,19,20,21,22,23,26,21,20,19,18,17};
        for(int i:arr){
            try {
                throttleController.calculateThrottle(i);
            }
            catch (Exception e){
                System.out.println(e);
            }

        }
//        final Integer throttleControlValue = throttleController.calculateThrottle(9);
//
//        setThrottleValue(throttleControlValue);
    }






}
