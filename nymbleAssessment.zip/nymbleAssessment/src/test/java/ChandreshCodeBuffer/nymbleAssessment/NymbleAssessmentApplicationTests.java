package ChandreshCodeBuffer.nymbleAssessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NymbleAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
