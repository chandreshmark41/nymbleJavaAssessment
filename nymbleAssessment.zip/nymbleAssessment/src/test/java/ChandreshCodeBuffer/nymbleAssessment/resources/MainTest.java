package ChandreshCodeBuffer.nymbleAssessment.resources;


import ChandreshCodeBuffer.nymbleAssessment.controller.ThrottleController;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.GetMapping;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MainTest {

    @Autowired
    ThrottleController throttleController;


    /***
     * throttleMethodTest1() first test case.
      */
    @Test
    @GetMapping("/callApi")
    public void throttleMethodTest1() {
        System.out.println("Nymble Assessment is runnig");
        int[] arr = {1,6,11,16,17,18,19,20,21,22,23,26,21,20,19,18,17};
        for(int i:arr){
            try {
                throttleController.calculateThrottle(i);
            }
            catch (Exception e){
                System.out.println(e);
            }

        }
//        final Integer throttleControlValue = throttleController.calculateThrottle(9);
//
//        setThrottleValue(throttleControlValue);
    }


    /***
     * throttleMethodTest2() second test case
      */
    @Test
    @GetMapping("/callApi")
    public void throttleMethodTest2() {
        System.out.println("Nymble Assessment is runnig");
        int[] arr = {1,6,11,16,17,18,19,20,21};
        for(int i:arr){
            try {
                throttleController.calculateThrottle(i);
            }
            catch (Exception e){
                System.out.println(e);
            }

        }
//        final Integer throttleControlValue = throttleController.calculateThrottle(9);
//
//        setThrottleValue(throttleControlValue);
    }

}
